package jjj.entropy.messages;


public class ActionMessage {
	public String message;
	
	public ActionMessage()
	{
	}
	
	
}
