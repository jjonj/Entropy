package jjj.entropy.classes;

public class Deck extends CardCollection {

	
	private Player owner;
	
	public Deck()
	{
		
	}
	
}
