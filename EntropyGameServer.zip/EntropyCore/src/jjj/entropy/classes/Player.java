package jjj.entropy.classes;

public class Player {

}
