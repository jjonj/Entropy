import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.io.PrintStream;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import jjj.entropy.messages.ChatMessage;



import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;
import com.esotericsoftware.kryonet.Server;


import com.esotericsoftware.kryonet.*;


public class EntServer {

	/**
	 * @param args
	 */
	static Server server;
	
	public static void main(String[] args) {
		
		
	     JFrame frame = new JFrame();
       frame.add( new JLabel(" Outout" ), BorderLayout.NORTH );
    
		
       
 //     WindowListener[] x = frame.getWindowListeners();
       
//     frame.removeWindowListener(x[0]);
      
      
      frame.addWindowListener(new WindowAdapter() {
           public void windowClosing(WindowEvent e) {
           	 
           	if (server != null)
       	     server.close();
           }
         });
       
      
       JTextArea ta = new JTextArea();
       ta.setPreferredSize(new Dimension(400, 400));
       

		server = new Server();
		server.start();
		try {
			server.bind(54555);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		   Kryo kryo = server.getKryo();
			kryo.register(ChatMessage.class);
			
		server.addListener(new Listener() {
			   public void received (Connection connection, Object object) {
			      if (object instanceof ChatMessage) {
			    	  ChatMessage request = (ChatMessage)object;
			         System.out.println(request.message);

			         ChatMessage response = new ChatMessage();
			         connection.sendTCP(response);
			      }
			   }
			});
		
		while (true)
		{
			try {
				Thread.sleep( 500 );
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
