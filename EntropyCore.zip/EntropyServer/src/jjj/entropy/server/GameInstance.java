package jjj.entropy.server;

import java.util.ArrayList;
import java.util.List;

import jjj.entropy.*;

public class GameInstance {

	private static final int MAX_GAME_COUNT = 100;
	
	private static GameInstance[] games = new GameInstance[MAX_GAME_COUNT];
	private static int gameCount;
	private static List<Integer> avaliableSlots = new ArrayList<Integer>();
	private static List<Integer> openGames = new ArrayList<Integer>();
	public int gameIndex;
	
	int  player1ID = -1,
		 player2ID = -1;
	

	public static int AssignToSlot(int playerID) {
		if (openGames.size() > 0)
		{
			int openGameIndex = openGames.get(openGames.size()-1);
			openGames.remove(openGames.size()-1);
			games[openGameIndex].AddPlayer(playerID);
			return openGameIndex;
			
		}
		else
		{
			if (avaliableSlots.size() > 0)
			{
				GameInstance newGameI = new GameInstance();
				int slotIndex = avaliableSlots.get(avaliableSlots.size()-1);
				avaliableSlots.remove(avaliableSlots.size()-1);
				games[slotIndex] = newGameI;
				newGameI.AddPlayer(playerID);
				
				return slotIndex;
			}
			else
			{
				if (gameCount < 100)
				{
					GameInstance newGameI = new GameInstance();
					games[gameCount] = newGameI;
					newGameI.AddPlayer(playerID);
					gameCount++;
					return gameCount-1;
				}
				else 
					return -1;
			}
		}
	}

	private void AddPlayer(int playerID) {
		if (player1ID == -1)
		{
			player1ID = playerID;
			openGames.add(gameIndex);
		}
		else
		{
			player2ID = playerID;
		}

	}

	private void RemovePlayer(int playerID) {
		if (player1ID == playerID)
		{
			player1ID = -1;
		}
		else
		{
			player2ID = -1;
		}
		if (player1ID + player2ID == -2)
		{
			avaliableSlots.add(gameIndex);
			games[gameIndex] = null;
		}
		
	}
	
	public static void PlayerLeave(int playerID, int gameID) {
		if (games[gameID] != null)
		{
			games[gameID].RemovePlayer(playerID);
		}
	}

	
	
	
}
