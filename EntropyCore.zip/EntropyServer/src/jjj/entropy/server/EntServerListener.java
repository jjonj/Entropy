package jjj.entropy.server;

import jjj.entropy.messages.ChatMessage;
import jjj.entropy.messages.GameMessage;

import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;


public class EntServerListener extends Listener {

	

	public void connected (Connection connection) {
		
		System.out.println(connection.getRemoteAddressTCP().toString() + " CONNECTING!");
		
	}
	

	public void disconnected (Connection connection) {
		System.out.println("SOMEONE DISCONNECTING!");
		
	}
	
	@Override
	public void received (Connection connection, Object object) {
		System.out.println("Message recieved");
		
		if (object instanceof ChatMessage) {
			System.out.println("ChatMessage recieved");
			ChatMessage request = (ChatMessage)object;
			System.out.println(request.message);
			
			ChatMessage response = new ChatMessage();
			connection.sendTCP(response);
		}
		else if(object instanceof GameMessage) {
			System.out.println("Gamemessage recieved");
			
			if (((GameMessage) object).disconnecting == false)
			{
				int instanceID = GameInstance.AssignToSlot(((GameMessage)object).playerID);
			
				if (instanceID != -1)
				{
					GameMessage response = new GameMessage();
					response.accepted = true;
					response.gameID = instanceID;
					connection.sendTCP(response);
					System.out.println("Player " + ((GameMessage)object).playerID + " has joined game instance " + instanceID);
				}
				else
				{
					GameMessage response = new GameMessage();
					response.accepted = false;
					connection.sendTCP(response);
					System.out.println("Player " + ((GameMessage)object).playerID + " could not connect to any game.");
				}
			}
			else
			{
				GameInstance.PlayerLeave(((GameMessage)object).playerID, ((GameMessage)object).gameID);
				System.out.println("Player " + ((GameMessage)object).playerID + " left game instance " + ((GameMessage)object).gameID);
			}
	    }
	}
	
}
