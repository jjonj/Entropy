package jjj.entropy.server;


import java.sql.*;

public class DatabaseManager {

	public boolean Connected = false;
	
	Connection conn;
	Statement stmt = null;
	ResultSet rs = null;
	
	public boolean Connect()
	{
		   
		try {
		    String url = "jdbc:mysql://localhost:3306/";
		    String dbName = "entropy";
		    String driver = "com.mysql.jdbc.Driver";
		    String userName = "root"; 
		    String password = "Agentaa3.";//"lolipop1pandora1";
		    conn = DriverManager.getConnection(url+dbName,userName,password);
		    Connected = true;
			return true;
		} catch (SQLException e) {
			// handle any errors
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    System.out.println("VendorError: " + e.getErrorCode());
		 //   System.exit(1);
		    return false;
		}
	}
	
	public void Disconnect()
	{
		try {
			conn.close();
		} catch (SQLException e) {
			try {
				Thread.sleep(200);
			} catch (InterruptedException e1) {
				System.out.println("FATAL ERROR: Cannot close DB Connection or sleep & retry. Close the connection manually!");
				e1.printStackTrace();
				System.exit(1);
			}
	//		Disconnect();
			   System.out.println("SQLException: " + e.getMessage());
			    System.out.println("SQLState: " + e.getSQLState());
			    System.out.println("VendorError: " + e.getErrorCode());
		}
		conn = null;
	}
	
   protected void finalize() throws SQLException
   {
   		if (conn != null)
   		{
   			conn.close();
   		}
   }

}
