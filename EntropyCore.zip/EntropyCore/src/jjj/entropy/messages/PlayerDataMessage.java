package jjj.entropy.messages;


public class PlayerDataMessage {
	
	public int playerID;
	public int[] deck;
	
	public PlayerDataMessage()
	{
		
			
	}
	
	
}
