package jjj.entropy.messages;


public class ChatMessage {
	public String message;
	
	public ChatMessage()
	{
	}
	
	
}
