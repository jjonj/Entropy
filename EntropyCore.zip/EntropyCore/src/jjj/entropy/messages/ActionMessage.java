package jjj.entropy.messages;


public class ActionMessage {
	
	public int cardID,
			   mode,
			   modeNumber;
	
	public ActionMessage()
	{
		
			
	}
	
	
}
