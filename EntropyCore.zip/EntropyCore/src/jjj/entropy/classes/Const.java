package jjj.entropy.classes;



public class Const {

	public static final String GAME_TITLE = "Entropy";
	
	public final static int START_GAME_WIDTH = 1280;
	public final static int START_GAME_HEIGHT = 720;

	public static final int MAX_CARD_COUNT = 10000;
	

}
