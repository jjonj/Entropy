package jjj.entropy.classes;

public class Player {

	String name;
	
	Deck deck;
	
	public Player(String name)
	{
		
	}
	
	
}
