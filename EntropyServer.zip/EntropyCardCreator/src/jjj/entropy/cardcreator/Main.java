package jjj.entropy.cardcreator;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollBar;
import java.awt.Choice;
import java.awt.Button;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


public class Main extends JFrame {

	private JPanel contentPane;
	private JTextField txfTitle;
	private JTextField txfRaceCost;
	private JTextField txfAnyCost;
	private JTextField txfGeneration;
	private JTextField txfDefense;
	private JTextField txfBaseDmg;
	private JTextField txfDiceDamage;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
					
				
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
	
	//	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
				DatabaseManager.GetInstance().Disconnect();
                System.exit(0);
            }
        });
		
		DatabaseManager.GetInstance().Connect();
		
		
		setBounds(100, 100, 420, 364);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
	
		
		
		JLabel lblCardTitle = new JLabel("Card title:");
		lblCardTitle.setBounds(56, 112, 61, 14);
		contentPane.add(lblCardTitle);
		
		JLabel lblResources = new JLabel("Resources:");
		lblResources.setBounds(22, 193, 68, 14);
		contentPane.add(lblResources);
		
		JLabel lblAnyCost = new JLabel("Race cost:");
		lblAnyCost.setBounds(90, 168, 81, 14);
		contentPane.add(lblAnyCost);
		
		JLabel lblAnyResource = new JLabel("Any cost:");
		lblAnyResource.setBounds(162, 168, 72, 14);
		contentPane.add(lblAnyResource);
		
		JLabel lblGeneration = new JLabel("Generation:");
		lblGeneration.setBounds(245, 168, 81, 14);
		contentPane.add(lblGeneration);
		
		txfTitle = new JTextField();
		txfTitle.setBounds(22, 137, 135, 20);
		contentPane.add(txfTitle);
		txfTitle.setColumns(10);
		
		txfRaceCost = new JTextField();
		txfRaceCost.setText("1");
		txfRaceCost.setBounds(100, 190, 31, 20);
		contentPane.add(txfRaceCost);
		txfRaceCost.setColumns(10);
		
		txfAnyCost = new JTextField();
		txfAnyCost.setText("1");
		txfAnyCost.setColumns(10);
		txfAnyCost.setBounds(172, 190, 31, 20);
		contentPane.add(txfAnyCost);
		
		txfGeneration = new JTextField();
		txfGeneration.setText("0");
		txfGeneration.setColumns(10);
		txfGeneration.setBounds(259, 190, 31, 20);
		contentPane.add(txfGeneration);
		
		JLabel lblStats = new JLabel("Stats:");
		lblStats.setBounds(22, 254, 61, 14);
		contentPane.add(lblStats);
		
		txfDefense = new JTextField();
		txfDefense.setText("0");
		txfDefense.setColumns(10);
		txfDefense.setBounds(100, 251, 31, 20);
		contentPane.add(txfDefense);
		
		JLabel lblDefense = new JLabel("Defense:");
		lblDefense.setBounds(90, 231, 53, 14);
		contentPane.add(lblDefense);
		
		JLabel lblBaseDamage = new JLabel("Base damage:");
		lblBaseDamage.setBounds(153, 231, 81, 14);
		contentPane.add(lblBaseDamage);
		
		txfBaseDmg = new JTextField();
		txfBaseDmg.setText("0");
		txfBaseDmg.setColumns(10);
		txfBaseDmg.setBounds(172, 251, 31, 20);
		contentPane.add(txfBaseDmg);
		
		txfDiceDamage = new JTextField();
		txfDiceDamage.setText("0");
		txfDiceDamage.setColumns(10);
		txfDiceDamage.setBounds(259, 251, 31, 20);
		contentPane.add(txfDiceDamage);
		
		JLabel lblDiceDamage = new JLabel("Dice Damage:");
		lblDiceDamage.setBounds(245, 231, 81, 14);
		contentPane.add(lblDiceDamage);
		
		JLabel lblEntropyCardCreator = new JLabel("Entropy Card Creator");
		lblEntropyCardCreator.setFont(new Font("LilyUPC", Font.BOLD, 32));
		lblEntropyCardCreator.setBounds(22, 11, 223, 29);
		contentPane.add(lblEntropyCardCreator);
		
		
		final JLabel lblMessageArea = new JLabel("...");
		lblMessageArea.setBounds(58, 52, 164, 17);
		contentPane.add(lblMessageArea);
		

		JLabel lblCardType = new JLabel("Card type:");
		lblCardType.setBounds(194, 112, 61, 14);
		contentPane.add(lblCardType);
		
		

	//	String[] cardTypes = {"Creature", "Structure", "Resource", "Resource Structure", "Spell", "Effect", "Zone Effect"};
		final Choice choice = new Choice();
		choice.add("Creature");
		choice.add("Structure");
		choice.add("Resource");
		choice.add("Resource Structure");
		choice.add("Spell");
		choice.add("Effect");
		choice.add("Zone Effect");
		choice.setBounds(165, 137, 125, 20);
		contentPane.add(choice);
		
		final Choice choice_1 = new Choice();
		choice_1.add("Orc");
		choice_1.add("Crawnid");
		choice_1.setBounds(298, 137, 96, 20);
		contentPane.add(choice_1);
		
		JButton btnNewButton = new JButton("Add card");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if (!DatabaseManager.GetInstance().CreateCard(txfTitle.getText(), Integer.parseInt(txfRaceCost.getText()), 
									Integer.parseInt(txfAnyCost.getText()), Integer.parseInt(txfGeneration.getText()), 
									Integer.parseInt(txfDefense.getText()), Integer.parseInt(txfBaseDmg.getText()),
									Integer.parseInt(txfDiceDamage.getText()), choice.getSelectedIndex(), choice_1.getSelectedIndex()+1))
				{
					lblMessageArea.setText("An error occoured!");
				}
				else
				{
					lblMessageArea.setText("Card created!");
				}
					
				
			}
		});
		btnNewButton.setBounds(129, 292, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnCreateList = new JButton("Create texture list");
		btnCreateList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				List<String> textureList = DatabaseManager.GetInstance().GenerateTextures();
				FileWriter outFile;
				try {
					outFile = new FileWriter("TextureList.etxl");
					PrintWriter out = new PrintWriter(outFile);
					for (String s : textureList)
					{
						out.println(s);
					}
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
					return;
				}
				lblMessageArea.setText("Texture list created!");
				             
			}
		});
		btnCreateList.setBounds(235, 292, 139, 23);
		contentPane.add(btnCreateList);
		
		JLabel lblCardRace = new JLabel("Card race:");
		lblCardRace.setBounds(313, 112, 61, 14);
		contentPane.add(lblCardRace);
		
		
		
	
		
	}
}
