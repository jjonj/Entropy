package jjj.entropy.messages;


public class ActionMessage {
	
	public int playerID,
			   cardID,
			   mode,
			   modeNumber;
	
	public ActionMessage()
	{
		
			
	}
	
	
}
