package jjj.entropy.messages;

public class LoginMessage {

	public String username,
	 			  password,
	 			  message;
	
	public boolean rejected = false;
	
}   
