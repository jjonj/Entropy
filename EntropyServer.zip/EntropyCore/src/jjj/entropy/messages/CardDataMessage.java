package jjj.entropy.messages;


public class CardDataMessage {
	public String[] cardTemplates;	//Each string consists of an encoded card template
	
	public CardDataMessage()
	{
	}
	
	
}
