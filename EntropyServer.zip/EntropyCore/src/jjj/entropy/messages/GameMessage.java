package jjj.entropy.messages;


public class GameMessage {
	public String message;
	public boolean accepted = false,
					disconnecting = false;
	public int gameID = -1;
	public int playerID; 
	public long seed1, seed2;
	
	public GameMessage()
	{
	}
	
	
}
