package jjj.entropy.messages;


public class PlayerDataMessage {
	
	public boolean loginAccepted = false;
	
	public String name;
	public int playerID;
	public int[] deck;
	
	public PlayerDataMessage()
	{	
	}
	
	
}
