package jjj.entropy.messages;


public class PlayerDataMessage {
	
	public boolean loginAccepted = false;
	
	public String name;
	public int playerID,
			   activeDeck;
	public int[] allCards;
	public int[][] decks;
	
	public PlayerDataMessage()
	{	
	}
	
	
}
