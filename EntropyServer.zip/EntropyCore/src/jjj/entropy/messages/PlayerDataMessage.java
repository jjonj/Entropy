package jjj.entropy.messages;


public class PlayerDataMessage {
	
	public boolean loginAccepted = false;
	
	public String name;
	public int playerID,
			   activeDeck;
	public int[] allCards;
	public int[] allCardCounts;
	
	public int[][] decks;

	public int[][] deckCounts;
	
	public PlayerDataMessage()
	{	
	}
	
	@Override 
	public String toString() {		//Counts are currently not printed FIX
	    StringBuilder result = new StringBuilder();
	    result.append("PlayerDataMessage - ");
	    result.append("name: " + name);
	    result.append(", loginAccepted: " + loginAccepted);
	    result.append(", playerID: " + playerID);
	    result.append(", active deck: " + activeDeck);
	    result.append(", allCards: ");
	    if (allCards != null)
	    {
		    for ( int s : allCards)
		    	result.append(s);
	    }
	    result.append(", decks: ");
	    if (decks != null)
	    {
		    for ( int[] s : decks)
		    {
		    	result.append(";");
		    	for(int k : s)
		    		result.append(k);
		    }
	    }
	   
	    return result.toString();
	}
}
