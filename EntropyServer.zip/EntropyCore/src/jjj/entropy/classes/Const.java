package jjj.entropy.classes;

//import jjj.entropy.classes.Enums.GameState;



public class Const {

	public static final String GAME_TITLE = "Entropy";
	
	public final static int START_GAME_WIDTH = 1280;
	public final static int START_GAME_HEIGHT = 720;
	public static final int MAX_GAME_COUNT = 100;
	public final static int MAX_PLAYERS_CONNECTED = 10;
	public static final int MAX_CARD_COUNT = 10000;

	//public static final GameState INIT_GAMESTATE = GameState.LOGIN;
	
	
	
	public final static float CARD_HEIGHT = 1.5f;
    public final static float CARD_WIDTH = 0.9f;
    public final static float HALF_CARD_HEIGHT = CARD_HEIGHT/2;	//I don't trust the compiler to optimize this
    public final static float HALF_CARD_WIDTH = CARD_WIDTH/2;
    public final static float CARD_THICKNESS = 0.001f;
    
    public static final float BOARD_LENGTH = 12.0f;
    public static final float BOARD_WIDTH = 12.0f;
    public static final float BOARD_HEIGHT = -0.001f;
    public static final float BOARD_THICKNESS = 0.5f;

    public static final float SMALL_BUTTON_WIDTH = 0.13f,
    						  SMALL_BUTTON_HEIGHT = 0.04f;
    
    public static final float BIG_BUTTON_WIDTH = 0.25f,
    					      BIG_BUTTON_HEIGHT = 0.075f;
    
    public static final float TINY_SQUARE_BUTTON_WIDTH = 0.040f,
    						  TINY_SQUARE_BUTTON_HEIGHT = 0.040f;
    
    public static final float TABLE_WIDTH = 0.35f,
    						  TABLE_ROW_HEIGHT = 0.0233f,
    						  TABLE_ROW_HEIGHT_PX = 19;		//Might want to calculate this instead
    public static final int TABLE_COLUMN_WIDTH_PX = 200;	//How much space each column has in a table. TODO: Should be editable FIX
    
    public static final float  DROPDOWN_ROW_HEIGHT = 0.0233f;
    public static final float  DROPDOWN_WIDTH = 0.2f;	
    
    
    
    public static final float SCROLL_HANDLE_HEIGHT = 0.035f;
    public static final float SCROLL_HANDLE_WIDHT = 0.009f;

    public static final int TEXTBOX_LINE_WIDTH = 205;
    
    public static final int CHAT_LINE_WIDTH = 240;
    public static final int CHAT_LINES = 5;
	public static final float TEXTBOX_HEIGHT = 0.05f,
							  TEXTBOX_WIDTH = 0.25f;

	public static final float CARD_SPACING = 2.2f;

}
