package jjj.entropy.classes;

import jjj.entropy.classes.Enums.GameState;



public class Const {

	public static final String GAME_TITLE = "Entropy";
	
	public final static int START_GAME_WIDTH = 1280;
	public final static int START_GAME_HEIGHT = 720;
	public static final int MAX_GAME_COUNT = 100;
	public final static int MAX_PLAYERS_CONNECTED = 10;
	public static final int MAX_CARD_COUNT = 10000;

	public static final GameState INIT_GAMESTATE = GameState.LOGIN;
	

}
