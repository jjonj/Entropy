package jjj.entropy.classes;


public class Enums {
	 public enum GameState{
	    	LOGIN, MAIN_MENU, IN_GAME, DECK_SCREEN
	    }
	    
	    public enum Life{
			LIFE1, LIFE2,LIFE3,LIFE4,
			O_LIFE1, O_LIFE2,O_LIFE3,O_LIFE4;
			
			public static float GetXLoc(Life l) {
		        switch(l) {
		        case LIFE1:
		            return -1.0f;
		        case LIFE2:
		            return 0.0f;
		        case LIFE3:
		            return 1.0f;
		        case LIFE4:
		            return 2f;
		        case O_LIFE1:
		            return 2.0f;
		        case O_LIFE2:
		            return 1.0f;
		        case O_LIFE3:
		            return 0.0f;
		        case O_LIFE4:
		            return -1f;
		        }
		        return -3;
		    }
		}
		public enum Zone{
			ZONE1,ZONE2,ZONE3,ZONE4;
			
			public static float GetZLoc(Zone z) {
		        switch(z) {
		        case ZONE1:
		            return 3f;
		        case ZONE2:
		            return 4.8f;
		        case ZONE3:
		            return 6.6f;
		        case ZONE4:
		            return 8.2f;
		        }
		        return -3;
		    }
		}
}
