package jjj.entropy.server;


import java.sql.*;

import jjj.entropy.messages.CardDataMessage;
import jjj.entropy.messages.PlayerDataMessage;

//Db actions are blocking! Make it threaded!

public class DatabaseManager 
{

	private static DatabaseManager instance = null ;
	
	public boolean Connected = false;
	
	Connection conn = null;
	Statement stmt = null;
	ResultSet resultSet = null;
	
	
	protected DatabaseManager(){}
	
	public static DatabaseManager GetInstance()
	{
		if (instance == null)
			instance = new DatabaseManager();
		return instance;
	}

	
	
	public boolean Login(PlayerDataMessage pdm, CardDataMessage cdm, String username, String password)
	{
		try {
			stmt = conn.createStatement();
			
			resultSet = stmt.executeQuery("select * from accounts where username = '" + username + "';");
		
			if (resultSet.next())	//If there was any result
			{
				
				if (resultSet.getString(5).equals(password))
				{
					//   	ID, TITLE, RACE,TYPE,COSTR,COSTA,INCOME,DEF,DMGB,DMGD
					
					cdm.cardTemplates = new String[] { 
							"0,Anid Queen,1,1,0,1,0,1,1,1",
							"1,Crawnid Worker,2,2,0,0,1,0,0,0",
							"2,Anid Larvae Swarm,1,1,0,1,0,1,1,1",
							"3,Darwinistic Innihilation,1,1,0,1,0,1,1,1",
						};
					
					
					pdm.loginAccepted = true;
					pdm.deck = new int[] { 0, 1, 1, 1, 1,1,1,1,1,1,1, 2, 3 };
	
					pdm.name = username;
					pdm.playerID = resultSet.getInt(1);	
					
					return true;
				}
				return false;
			}
			else
				return false;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
		
		return true;
	}
	
	public boolean Connect()
	{
		   
		try {
		    String url = "jdbc:mysql://localhost:3306/";
		    String dbName = "entropy";
		    String driver = "com.mysql.jdbc.Driver";
		    String userName = "root"; 
		    String password = "Agentaa3.";//"lolipop1pandora1";
		    conn = DriverManager.getConnection(url+dbName,userName,password);
		    Connected = true;
			return true;
		} catch (SQLException e) {
			// handle any errors
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    System.out.println("VendorError: " + e.getErrorCode());
		 //   System.exit(1);
		    return false;
		}
	}
	
	public void Disconnect()
	{
		try {
			conn.close();
		} catch (SQLException e) {
			try {
				Thread.sleep(200);
			} catch (InterruptedException e1) {
				System.out.println("FATAL ERROR: Cannot close DB Connection or sleep & retry. Close the connection manually!");
				e1.printStackTrace();
				System.exit(1);
			}
	//		Disconnect();
			   System.out.println("SQLException: " + e.getMessage());
			    System.out.println("SQLState: " + e.getSQLState());
			    System.out.println("VendorError: " + e.getErrorCode());
		}
		conn = null;
	}
	
   protected void finalize() throws SQLException
   {
   		if (conn != null)
   		{
   			conn.close();
   		}
   }

}
