package jjj.entropy.server;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import jjj.entropy.messages.CardDataMessage;
import jjj.entropy.messages.PlayerDataMessage;

//Db actions are blocking! Make it threaded!

public class DatabaseManager 
{

	private static DatabaseManager instance = null ;
	
	public boolean Connected = false;
	
	Connection conn = null;
	Statement stmt = null;
	ResultSet resultSet = null;
	
	
	protected DatabaseManager(){}
	
	public static DatabaseManager GetInstance()
	{
		if (instance == null)
			instance = new DatabaseManager();
		return instance;
	}

	
	public void GetPlayerInfo(int playerID, PlayerDataMessage pdm, CardDataMessage cdm, boolean onlyActiveDeck)
	{
		try {
			
			//First get the player information
			stmt = conn.createStatement();			
			resultSet = stmt.executeQuery("select * from accounts where account_id = '" + playerID + "'");
		
			String username;
			if (resultSet.next())
			{
				username = resultSet.getString("username");
			}
			else 
				return;	//This should never happen
		
			//Next we get all the cards owned by a user so they can be loaded by the client
			
			Statement stmt2  = conn.createStatement();
			ResultSet resultSet2 = stmt2.executeQuery("select distinct cards.* from cards "+			//Get all cards owned  by user
													  "join card_collection_relation "+
													  "on cards.card_id = card_collection_relation.card_id "+
													  "join card_collections "+
													  "on card_collection_relation.collection_id = card_collections.collection_id "+
													  "where account_id = " + playerID);
			
			List<String> results = new ArrayList<String>();
			
			
			while (resultSet2.next())	//Load all the cards and gather their string encodings
			{
				// Encoding:  	ID,TITLE,RACE,TYPE,COSTR,COSTA,INCOME,DEF,DMGB,DMGD
				results.add(resultSet2.getInt("card_id")+","+resultSet2.getString("title")+","+resultSet2.getInt("race")+","+resultSet2.getInt("type")+","+
						resultSet2.getInt("race_cost")+","+resultSet2.getInt("any_cost")+","+resultSet2.getInt("income")+","+resultSet2.getInt("defense")+
						","+resultSet2.getInt("dmg_base")+","+resultSet2.getInt("dmg_dice"));
			}
			
			
			cdm.cardTemplates  = (String[]) results.toArray(new String[results.size()]);
			
			
			pdm.loginAccepted = false;	//Note related to login
			
			int DBActiveDeck = resultSet.getInt("active_deck_id");
			
			
			if (!onlyActiveDeck)	//If asked to get full information (which happens on login, partial information is requested when getting opponent info)
			{
				List<Integer> allCardList = new ArrayList<Integer>();
				List<Integer> allCardCounts = new ArrayList<Integer>();
				//Type 1 collections are allcards collections
				//Get cards in the all cards collection (type 1) for that player (SINCE ITS A 1 TO 1 RELATION BETWEEN ACC AND TYPE 1, CONSIDER DIRECT REFERENCE IN DB)
				stmt2  = conn.createStatement();
				resultSet2 = stmt2.executeQuery("select card_id, count from card_collection_relation "+
										"where collection_id IN (select collection_id from card_collections where account_id = "+ playerID +
										" AND collection_type = 1)");
				
				//For each card the player owns in his all collection
				while (resultSet2.next())	
				{
					allCardList.add(resultSet2.getInt("card_id"));
					allCardCounts.add(resultSet2.getInt("count"));
				}
				
				pdm.allCards = new int[allCardList.size()];	//Really ugly!
				pdm.allCardCounts = new int[allCardList.size()];
			    for (int i = 0; i < pdm.allCards.length; i++)
			    {
			 
			    	pdm.allCards[i] = allCardList.get(i).intValue();
			    	pdm.allCardCounts[i] = allCardCounts.get(i).intValue();
			    }			
						
			    
			    //Get all decks by that player
				stmt2  = conn.createStatement();
				resultSet2 = stmt2.executeQuery("select collection_id from card_collections where account_id = "+playerID+" AND collection_type = 2");
				
				
				List<Integer> deckIDs = new ArrayList<Integer>();
					
				
				//Foreach of the players decks
				while (resultSet2.next())	
				{
					int tempDeckID = resultSet2.getInt("collection_id");
					deckIDs.add(tempDeckID);
					if (tempDeckID == DBActiveDeck)	//If the current deck is the players active deck
						pdm.activeDeck = deckIDs.size()-1;	//Converted from DB active deck to index in the returned deck array
				}
				
				pdm.decks = new int[deckIDs.size()][];	//Allocate space for each array
				pdm.deckCounts = new int[deckIDs.size()][];	
				
				
				
				List<Integer> tempDeck = new ArrayList<Integer>();
				List<Integer> tempDeckCounts = new ArrayList<Integer>();
				int deckCounter = 0;
				for (Integer did : deckIDs)	//Iterate each deck and get the id's from that deck
				{
					//Get the card id's and counts for the current deck
					stmt2  = conn.createStatement();
					resultSet2 = stmt2.executeQuery("select card_id, count from card_collection_relation where collection_id = "+did +" order by card_id");
					while (resultSet2.next())	
					{
						tempDeck.add(resultSet2.getInt("card_id"));
						tempDeckCounts.add(resultSet2.getInt("count"));
					}

					pdm.decks[deckCounter] = new int[tempDeck.size()];	//Really ugly!
					pdm.deckCounts[deckCounter] = new int[tempDeck.size()];
				    for (int i = 0; i < tempDeck.size(); i++)
				    {
				    	pdm.decks[deckCounter][i] = tempDeck.get(i).intValue();	//Assign card id for the current deck
				    	pdm.deckCounts[deckCounter][i] = tempDeckCounts.get(i).intValue();	//Assign card count 
				    }	
				    deckCounter++;
				    tempDeck.clear();
				}

			}
			else	//If only asked to get the active deck
			{
				List<Integer> activeDeckList = new ArrayList<Integer>();
				List<Integer> activeDeckCounts = new ArrayList<Integer>();

				stmt  = conn.createStatement();
				resultSet = stmt.executeQuery("select card_id, count from card_collection_relation where collection_id = "+DBActiveDeck+" order by card_id");	//Get card id's from active deck
				while (resultSet.next())	
				{
					activeDeckList.add(resultSet.getInt("card_id"));
					activeDeckCounts.add(resultSet.getInt("count"));
				}
				if (activeDeckList.size() == 0)
				{
					pdm.decks = null;	//Active deck have no cards for that player
					pdm.activeDeck = -1;
				}
				else
				{
					pdm.decks = new int[1][];	//Just 1 deck in the decks collection (the active deck)
					pdm.deckCounts = new int[1][];	//Just 1 deck in the decks collection (the active deck)
					
					pdm.decks[0] = new int[activeDeckList.size()];
					pdm.deckCounts[0] = new int[activeDeckList.size()];
					try {
					    for (int i = 0; i < activeDeckList.size(); i++)
					    {
					    	pdm.decks[0][i] = activeDeckList.get(i).intValue();	
					    	pdm.deckCounts[0][i] = activeDeckCounts.get(i).intValue();
					    }	
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				    pdm.activeDeck = 0;
				}
			}
			
			
			pdm.name = username;
			pdm.playerID = playerID;	
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	
	public boolean Login(PlayerDataMessage pdm, CardDataMessage cdm, String username, String password)
	{
		try {
			stmt = conn.createStatement();
			
			resultSet = stmt.executeQuery("select * from accounts where username = '" + username + "';");
		
			if (resultSet.next())	//If there was any result
			{
				
				if (resultSet.getString(5).equals(password))
				{
		
					GetPlayerInfo(resultSet.getInt(1), pdm, cdm, false);
					pdm.loginAccepted = true;
					
					return true;
				}
					
				return false;
			}
			else
				return false;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
		
		return true;
	}
	
	public boolean Connect()
	{
		   
		try {
		    String url = "jdbc:mysql://localhost:3306/";
		    String dbName = "entropy";
		    String driver = "com.mysql.jdbc.Driver";
		    String userName = "root"; 
		    String password = "Agentaa3.";//"lolipop1pandora1";
		    conn = DriverManager.getConnection(url+dbName,userName,password);
		    Connected = true;
			return true;
		} catch (SQLException e) {
			// handle any errors
		    System.out.println("SQLException: " + e.getMessage());
		    System.out.println("SQLState: " + e.getSQLState());
		    System.out.println("VendorError: " + e.getErrorCode());
		 //   System.exit(1);
		    return false;
		}
	}
	
	public void Disconnect()
	{
		try {
			conn.close();
		} catch (SQLException e) {
			try {
				Thread.sleep(200);
			} catch (InterruptedException e1) {
				System.out.println("FATAL ERROR: Cannot close DB Connection or sleep & retry. Close the connection manually!");
				e1.printStackTrace();
				System.exit(1);
			}
	//		Disconnect();
			   System.out.println("SQLException: " + e.getMessage());
			    System.out.println("SQLState: " + e.getSQLState());
			    System.out.println("VendorError: " + e.getErrorCode());
		}
		conn = null;
	}
	
   protected void finalize() throws SQLException
   {
   		if (conn != null)
   		{
   			conn.close();
   		}
   }

}
