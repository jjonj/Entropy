package jjj.entropy.server;

import jjj.entropy.classes.Const;
import jjj.entropy.classes.EntUtilities;
import jjj.entropy.messages.ActionMessage;
import jjj.entropy.messages.CardDataMessage;
import jjj.entropy.messages.ChatMessage;
import jjj.entropy.messages.GameMessage;
import jjj.entropy.messages.LoginMessage;
import jjj.entropy.messages.PlayerDataMessage;

import com.esotericsoftware.kryonet.Connection;
import com.esotericsoftware.kryonet.Listener;


public class EntServerListener extends Listener {

	private int connectedPlayerCount;
	public Connection[] connections = new Connection[Const.MAX_PLAYERS_CONNECTED];	//Is actually max players logged in (connect and login will happen at the same time later FIX)
	
	@Override
	public void connected (Connection connection) {
		
		System.out.println(connection.getRemoteAddressTCP().toString() + " CONNECTING!");
		
	}
	
	@Override
	public void disconnected (Connection connection) {
		
		
		// ASSOCIATE PLAYER IDS WITH IPS SO PLAYERS CAN BE PROPERLY LOGGED OUT. ALSO DECREMENT WHEN PLAYER LOGS OUT
		System.out.println("SOMEONE DISCONNECTING!");
		
	}
	
	@Override
	public void received (Connection connection, Object object) {
		
		if (object instanceof ChatMessage) {
			System.out.println("ChatMessage recieved");
			ChatMessage request = (ChatMessage)object;
			System.out.println(request.message);
			
			ChatMessage response = new ChatMessage();
			connection.sendTCP(response);
		}
		else if(object instanceof GameMessage) 
		{
			System.out.println("Gamemessage recieved");
			
			if (((GameMessage) object).disconnecting == false)
			{
				
				int otherPlayerID[] = { -1 };	// Output parameter, using array as a hack, could also use a wrapper instead
				int instanceID = GameInstance.AssignToSlot(((GameMessage)object).playerID, otherPlayerID);
			
				
				
				if (instanceID != -1)
				{
		
					if (otherPlayerID[0] != -1)	//If both players are now present
					{
						
						PlayerDataMessage opponentTo1 = new PlayerDataMessage();
						PlayerDataMessage opponentTo2 = new PlayerDataMessage();
						opponentTo1.deck = new int[] { 0, 1, 1, 1, 1,1,1,1,1,1,1, 2, 3 };	//Ugly as fuck! this is sent regardless of which opponent it is
						opponentTo2.deck = new int[] { 0, 1, 1, 1, 1,1,1,1,1,1,1, 2, 3 };	
						opponentTo1.loginAccepted = false;
						opponentTo2.loginAccepted = false;
						opponentTo1.name = "Otherplayer"; //Yeah...
						opponentTo2.name = "Otherplayer"; 
						opponentTo1.playerID = 2;
						opponentTo2.playerID = 2;

						connections[otherPlayerID[0]].sendTCP(opponentTo1);
						connection.sendTCP(opponentTo2);
						
						GameMessage responseTo1 = new GameMessage();
						GameMessage responseTo2 = new GameMessage();
						responseTo1.accepted = true;
						responseTo2.accepted = true;
						responseTo1.gameID = instanceID;
						responseTo2.gameID = instanceID;
						responseTo1.seed1 = (long)EntUtilities.GetRandom(0, 10000, 1);	//Is this proper?
						responseTo1.seed2 = (long)EntUtilities.GetRandom(0, 10000, 1);
						responseTo2.seed1 = responseTo1.seed1;
						responseTo2.seed2 = responseTo1.seed2;
						connections[otherPlayerID[0]].sendTCP(responseTo1);
						connection.sendTCP(responseTo2);
						System.out.println("Player " + ((GameMessage)object).playerID + " has joined game instance " + instanceID);
						System.out.println("Player " + otherPlayerID[0] + " has joined game instance " + instanceID);
					}
				}
				else
				{
					GameMessage response = new GameMessage();
					response.accepted = false;
					connection.sendTCP(response);
					System.out.println("Player " + ((GameMessage)object).playerID + " could not connect to any game.");
				}
			}
			else
			{
				GameInstance.PlayerLeave(((GameMessage)object).playerID, ((GameMessage)object).gameID);
				System.out.println("Player " + ((GameMessage)object).playerID + " left game instance " + ((GameMessage)object).gameID);
			}
	    }
		else if (object instanceof LoginMessage)
		{
			System.out.println("LoginMesage recieved!!");
			if (connectedPlayerCount < Const.MAX_PLAYERS_CONNECTED)
			{
				
				
				LoginMessage lgmsg = (LoginMessage)object;
				if (lgmsg.password.equals("lol") && lgmsg.username.equalsIgnoreCase("crovea"))
				{
					
					connectedPlayerCount++;
					CardDataMessage playerDeck = new CardDataMessage();
											//   	ID, TITLE, RACE,TYPE,COSTR,COSTA,INCOME,DEF,DMGB,DMGD
					playerDeck.cardTemplates = new String[] { 
						"0,Anid Queen,1,1,0,1,0,1,1,1",
						"1,Crawnid Worker,2,2,0,0,1,0,0,0",
						"2,Anid Larvae Swarm,1,1,0,1,0,1,1,1",
						"3,Darwinistic Innihilation,1,1,0,1,0,1,1,1",
					};
					
					PlayerDataMessage player = new PlayerDataMessage();
					player.deck = new int[] { 0, 1, 1, 1, 1,1,1,1,1,1,1, 2, 3 };
					player.name = lgmsg.username;
					player.loginAccepted = true;
					player.playerID = 0;	//GET THIS FROM DATABASE OBV
					connections[player.playerID] = connection;	//Remember connection for this player
					
					connection.sendTCP(playerDeck);
					connection.sendTCP(player);
					System.out.println(lgmsg.username + " has logged in!");
					
				}
				else if (lgmsg.password.equals("lol") && lgmsg.username.equalsIgnoreCase("crovea2"))
				{
					connectedPlayerCount++;
					CardDataMessage playerDeck = new CardDataMessage();
											//   	ID, TITLE, RACE,TYPE,COSTR,COSTA,INCOME,DEF,DMGB,DMGD
					playerDeck.cardTemplates = new String[] { 
							"0,Anid Queen,1,1,0,1,0,1,1,1",
							"1,Crawnid Worker,2,2,0,0,1,0,0,0",
							"2,Anid Larvae Swarm,1,1,0,1,0,1,1,1",
							"3,Darwinistic Innihilation,1,1,0,1,0,1,1,1",
						};
					PlayerDataMessage player = new PlayerDataMessage();
					player.deck = new int[] { 0, 1, 1, 1, 1,1,1,1,1,1,1, 2, 3 };
					player.name = lgmsg.username;
					player.loginAccepted = true;
					player.playerID = 1;	//GET THIS FROM DATABASE OBV LIKE EVERYTHING ELSE IN HERE
					connections[player.playerID] = connection;	//Remember connection for this player
					
					connection.sendTCP(playerDeck);
					connection.sendTCP(player);
					System.out.println(lgmsg.username + " has logged in!");
				}
				else
				{
					LoginMessage reject = new LoginMessage();
					reject.rejected = true;
					connection.sendTCP(reject);
				}
			}
			else
			{
				System.out.println("It was rejected, since server has reached maximum capacity: " + Const.MAX_PLAYERS_CONNECTED);
				LoginMessage reject = new LoginMessage();
				reject.rejected = true;
				connection.sendTCP(reject);
			}
		}
		else if (object instanceof ActionMessage)	//Simply redirect the message to the other player.
		{
			int playerID = ((ActionMessage) object).playerID;
			connections[GameInstance.GetOtherPlayerID(playerID)].sendTCP(object);
		}
	}
	
}
