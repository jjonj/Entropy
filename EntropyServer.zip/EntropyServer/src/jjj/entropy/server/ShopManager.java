package jjj.entropy.server;

import jjj.entropy.messages.Purchase;

public class ShopManager 
{

	
	
	
	private static final int 
					  startersCommon = 7,
					  startersUnCommon = 2,
					  startersRare = 0,
					  startersLegendary = 0,
					  
					  collectorsCommon = 5,
					  collectorsUncommon = 3,
					  collectorsRare = 1,
					  collectorsLegendary = 0,
					  
					  goldCommon = 3,
					  goldUncommon = 3,
					  goldRare = 3,
					  goldLegendary = 0;
	
	
	public static String GenerateStartersPack()
	{
		
		StringBuilder result = new StringBuilder();
		
		for (int i = 0; i < startersCommon; i++)
		{
			result.append(DatabaseManager.GetInstance().GetRandomCommon()+",");
		}
		for (int i = 0; i < startersUnCommon; i++)
		{
			result.append(DatabaseManager.GetInstance().GetRandomUncommon()+",");
		}
		
		for (int i = 0; i < startersRare; i++)
		{
			result.append(DatabaseManager.GetInstance().GetRandomRare()+",");
		}
		for (int i = 0; i < startersLegendary; i++)
		{
			result.append(DatabaseManager.GetInstance().GetRandomLegendary()+",");
		}
		
		result.append(DatabaseManager.GetInstance().GetRandomProbability(0.8f, 0f, 19.9f));
		
		return result.toString();
	}
	
	public static String GenerateCollectorsPack()
	{
		StringBuilder result = new StringBuilder();
		
		for (int i = 0; i < collectorsCommon; i++)
		{
			result.append(DatabaseManager.GetInstance().GetRandomCommon()+",");
		}
		for (int i = 0; i < collectorsUncommon; i++)
		{
			result.append(DatabaseManager.GetInstance().GetRandomUncommon()+",");
		}
		for (int i = 0; i < collectorsRare; i++)
		{
			result.append(DatabaseManager.GetInstance().GetRandomRare()+",");
		}
		for (int i = 0; i < collectorsLegendary; i++)
		{
			result.append(DatabaseManager.GetInstance().GetRandomLegendary()+",");
		}
		
		result.append(DatabaseManager.GetInstance().GetRandomProbability(0.8f, 0f, 19.5f));
		
		return result.toString();
	}
	
	public static String GenerateGoldPack()
	{
		StringBuilder result = new StringBuilder();
		
		for (int i = 0; i < goldCommon; i++)
		{
			result.append(DatabaseManager.GetInstance().GetRandomCommon()+",");
		}
		for (int i = 0; i < goldUncommon; i++)
		{
			result.append(DatabaseManager.GetInstance().GetRandomUncommon()+",");
		}
		for (int i = 0; i < goldRare; i++)
		{
			result.append(DatabaseManager.GetInstance().GetRandomRare()+",");
		}
		for (int i = 0; i < goldLegendary; i++)
		{
			result.append(DatabaseManager.GetInstance().GetRandomLegendary()+",");
		}
		
		result.append(DatabaseManager.GetInstance().GetRandomProbability(0.5f, 0.3f, 18.5f));
		
		return result.toString();
	}

	public static boolean ValidatePurchase(Purchase purchase) 
	{
		purchase.accepted = true;
		purchase.data = ShopItem.shopItemMap.get(purchase.itemID).GetData();
		
		return true;
	}
	
}
