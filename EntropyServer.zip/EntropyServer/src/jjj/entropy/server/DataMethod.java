package jjj.entropy.server;

public interface DataMethod 
{
	public String[] GetData();	
}

